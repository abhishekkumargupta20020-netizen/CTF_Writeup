# Config intranet Tricatel
DEBUG = False
DB_HOST = "10.0.0.5"
fin config
