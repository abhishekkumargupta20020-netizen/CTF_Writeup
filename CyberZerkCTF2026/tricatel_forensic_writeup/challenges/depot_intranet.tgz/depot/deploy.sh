#!/bin/sh
# Script de déploiement
API_KEY="$DEPLOY_API_KEY"   # lu depuis l'environnement maintenant
echo "Déploiement"
